Splits obtained from Georgia Gkioxari
