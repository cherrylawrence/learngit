Store the MPII tfrecords here
