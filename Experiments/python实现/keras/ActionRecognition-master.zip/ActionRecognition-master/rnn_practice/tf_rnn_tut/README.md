
This is the code of the [tensorflow RNN
tutorial](https://www.tensorflow.org/tutorials/recurrent).
 
I commented the code to fully understand how to implement RNN with tf.
