//
// Created by Yuanjun Xiong on 18/11/2015.
//

#ifndef DENSEFLOW_UTILS_H
#define DENSEFLOW_UTILS_H

#include "common.h"

void writeZipFile(vector<vector<uchar> >& data, string name_temp, string archive_name);

#endif //DENSEFLOW_UTILS_H
