#ifndef CLUE_CONTAINER_COMMON__
#define CLUE_CONTAINER_COMMON__

#include <clue/type_traits.hpp>
#include <utility>
#include <algorithm>
#include <functional>
#include <initializer_list>
#include <iterator>
#include <limits>

#endif
