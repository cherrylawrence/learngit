# VideoActionRecognition
This repo contains the code for a research project, which tries to use semi-supervised learning to recognize human actions in videos. The data set we use is the dataset for THUMOS 2014 competition. 
## Finished tasks
## Next Tasks
* change the user interface, so that user have more argument options
* Better Documentation
